

<?php $__env->startSection('title', 'Update Agent Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-container">
    <h1>Update Your Details</h1>
    
    <!-- Display validation errors if any -->
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Update Form -->
    <form method="POST" action="<?php echo e(route('agent.update')); ?>">
        <?php echo csrf_field(); ?>

        <!-- Name Input -->
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo e($agent->name); ?>" required>
        </div>

        <!-- Surname Input -->
        <div class="form-group">
            <label for="surname">Surname:</label>
            <input type="text" class="form-control" id="surname" name="surname" value="<?php echo e($agent->surname); ?>" required>
        </div>

        <!-- Address Input -->
        <div class="form-group">
            <label for="address">Address:</label>
            <input type="text" class="form-control" id="address" name="address" value="<?php echo e($agent->address); ?>" required>
        </div>

        <!-- Submit Button -->
        <button type="submit" class="btn btn-success">Update</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<style>
.dashboard-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100vh;
    text-align: center;
}

form {
    width: 50%;
    margin-top: 20px;
}

.form-group {
    margin-bottom: 15px;
}

button {
    width: 100%;
}
</style>

<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LoginPage\user_roles_system\resources\views/agent/edit.blade.php ENDPATH**/ ?>