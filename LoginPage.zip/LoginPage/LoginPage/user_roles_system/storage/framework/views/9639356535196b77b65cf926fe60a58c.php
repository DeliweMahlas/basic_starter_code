<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?> | Profile Dashboard</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
  
    </header>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

   
</body>

</html>
<style>
    footer {
        font-size: 14px;
        color: #6c757d;
    }

</style>
<?php /**PATH C:\Users\user\Desktop\LoginPage\LoginPage\user_roles_system\resources\views/layouts.blade.php ENDPATH**/ ?>