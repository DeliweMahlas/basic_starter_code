
<?php $__env->startSection('title', 'User Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-container">
    <h1>User Dashboard</h1>
    <p>Welcome, <?php echo e($user->name); ?>!</p>

    <!-- Display Agent Details -->
    <div class="agent-details">
        <h3>Your Details</h3>
        <p><strong>Name:</strong> <?php echo e($user->name); ?></p>
        <p><strong>Surname:</strong> <?php echo e($user->surname); ?></p>
        <p><strong>Address:</strong> <?php echo e($user->address); ?></p>
        <p><strong>Email:</strong> <?php echo e($user->email); ?></p>
    </div>

    <!-- Update Button -->
    <a href="<?php echo e(route('agent.edit')); ?>" class="btn btn-success btn-lg mt-3">Update Details</a>
</div>

</div>

    <!-- Update Button -->
    <a href="<?php echo e(route('logout')); ?>" class="btn btn-success btn-lg mt-3">Logout</a>
</div>
<?php $__env->stopSection(); ?>

<style>
.dashboard-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100vh;
    text-align: center;
}

.agent-details {
    margin-top: 20px;
    text-align: left;
}
</style>

<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LoginPage\user_roles_system\resources\views/dashboard/user.blade.php ENDPATH**/ ?>